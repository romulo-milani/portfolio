This is the third project of freeCodeCamp.com. 
The goal is to create a product landing page similar to this:https://codepen.io/freeCodeCamp/full/RKRbwL.
Use FIREFOX to view this project, for some reason, google chrome doesn't display some elements correctly.
If the video doesn't display correctly, try opening the page in a private window.
